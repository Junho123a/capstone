import pymysql

def get_user_preference(userid='user01'):
    # 데이터베이스 연결
    conn = pymysql.connect(
        host='localhost',
        user='root',
        password='1qaz2wsx',
        db='capstone',
        charset='utf8'
    )
    try:
        cur = conn.cursor()
        sql = "SELECT preference FROM portfolio WHERE userid = %s"
        cur.execute(sql, (userid,))
        result = cur.fetchone()
        if result:
            return result[0]  # 성향 값 반환
        else:
            return None  # 해당 사용자가 없을 때
    finally:
        conn.close()
