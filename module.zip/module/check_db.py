import pymysql

# 데이터베이스 연결
conn = pymysql.connect(
    host='localhost',
    user='root',
    password='1qaz2wsx',
    db='capstone',
    charset='utf8'
)

# 커서 생성
cur = conn.cursor()

# 쿼리 실행
cur.execute("SELECT * FROM portfolio")

# 결과 가져오기
rows = cur.fetchall()
for row in rows:
    print(row)
#예시
#(1, 'user01', 'password123', '홍길동', '공격형')
#(2, 'user02', 'mypassword', '김철수', '안정형')

# 연결 종료
conn.close()
